# Python-Sockets
Pequeña guia sobre como utilizar sockets no bloqueantes en python mediante la creación de un chat.
